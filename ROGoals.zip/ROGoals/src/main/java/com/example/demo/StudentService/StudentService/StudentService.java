package com.example.demo.StudentService.StudentService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.repository.PracticeRepository;
@Service
public class StudentService {
@Autowired
PracticeRepository practiceRepository;
	public List<Student> getAll() {
		return practiceRepository.getAll();
	}
	public String add(Student stud) {
		return practiceRepository.add(stud);
	}
	public String edit(Student stud) {
		return practiceRepository.edit(stud);
	}
	public String delete(int studNo) {
		return practiceRepository.delete(studNo);
	}

}
