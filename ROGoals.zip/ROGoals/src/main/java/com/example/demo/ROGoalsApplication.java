package com.example.demo;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entity.Student;
import com.example.demo.repository.PracticeRepository;

@SpringBootApplication
public class ROGoalsApplication implements CommandLineRunner{
	@Autowired
	PracticeRepository practiceRepository;

	public static void main(String[] args) {
		SpringApplication.run(ROGoalsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Student s1=new Student(1,"Student1",7,"A");
		Student s2=new Student(2,"Student2",10,"A");
		Student s3=new Student(3,"Student3",1,"A");
		Student s4=new Student(4,"Student4",9,"A");
		Student s5=new Student(5,"Student5",10,"A");
		
		practiceRepository.student.addAll((Arrays.asList(s1,s2,s3,s4,s5)));
		
	}

}
