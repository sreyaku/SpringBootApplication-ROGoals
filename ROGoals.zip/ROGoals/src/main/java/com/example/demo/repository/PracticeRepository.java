package com.example.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.Student;

@Repository
public class PracticeRepository {

	 public List<Student>student =new ArrayList <Student>();
     public List<Student> getAll(){
		return student;
    	 
     }
	public String add(Student stud) {
		student.add(stud);
		return "Successfully added";
	}
	public String edit(Student stud) {
		student.stream().filter(e ->e.getId()==stud.getId()).forEach(e ->{
			
		e.setStudentName(stud.getStudentName());
		e.setClassStudying(stud.getClassStudying());
		e.setDivision(stud.getDivision());
	}
	);
		return "Successfully updated";
	}
	public String delete(int studNo) {
		student.remove(studNo-1);
		return "deleted";
	}
}


