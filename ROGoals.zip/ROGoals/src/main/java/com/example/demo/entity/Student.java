package com.example.demo.entity;

public class Student {
	
	private int Id;
	private String StudentName;
	private int ClassStudying;
	private String Division;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getStudentName() {
		return StudentName;
	}
	public void setStudentName(String studentName) {
		StudentName = studentName;
	}
	public Student(int id, String studentName, int classStudying, String division) {
		super();
		Id = id;
		StudentName = studentName;
		ClassStudying = classStudying;
		Division = division;
	}
	public int getClassStudying() {
		return ClassStudying;
	}
	public void setClassStudying(int classStudying) {
		ClassStudying = classStudying;
	}
	public String getDivision() {
		return Division;
	}
	public void setDivision(String division) {
		Division = division;
	}

}
